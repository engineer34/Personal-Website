$(function() {
    // Initialize the Selectable plugin on the appropriate elements
    $("#selectable").selectable({
        // Add any necessary options or callbacks here
    });

    // Apply custom CSS changes
    $(".ui-widget-content").css({
        "font-family": "Arial", // Change font for selectable items
        "border": "2px solid #ccc", // Increase border width of selectable items
        "background-color": "#AAA439" // Change background color of selectable items
    });

    // Apply customizations/personalizations to the plugin
    $("#selectable").addClass("custom-selectable"); // Add a custom class for further styling
    $("#selectable").prepend("<h2>Selectable Items</h2>"); // Add a heading to the selectable items
});