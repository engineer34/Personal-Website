/*    JavaScript 6th Edition
 *    Chapter 6
 *    Chapter case

 *    
 *    Variables and functions
 *    Author: 
 *    Date:   

 *    Filename: snoot.js
 */

"use strict"; // interpret document contents in JavaScript strict mode



/* create event listeners */
function createEventListeners() {

    var phnFields = document.getElementsByClassName("billPhone");
    for (var i = 0; i < phnFields.length; i++) {
        if (phnFields[i].addEventListener) {
         phnFields[i].addEventListener("input", advancePhone, false);
        } else if (phnFields[i].attachEvent) {
         phnFields[i].attachEvent("oninput", advancePhone);
        }
    }

    var delivphnFields = document.getElementsByClassName("delivPhone");
    for (var i = 0; i < delivphnFields.length; i++) {
        if (delivphnFields[i].addEventListener) {
         delivphnFields[i].addEventListener("input", advanceDelivPhone, false);
        } else if (delivphnFields[i].attachEvent) {
         delivphnFields[i].attachEvent("oninput", advanceDelivPhone);
        }
    }


}

/* run setup functions when page finishes loading */
if (window.addEventListener) {
    window.addEventListener("load", createEventListeners, false);
} else if (window.attachEvent) {
    window.attachEvent("onload", createEventListeners);
}


function advancePhone() {
    var phnFields = document.getElementsByClassName("billPhone");
    var currentField = document.activeElement;
    if (currentField.value.length === currentField.maxLength) {
        if (currentField === phnFields[0]) {
         phnFields[1].focus();
        }
        if (currentField === phnFields[1]) {
         phnFields[2].focus();
        }
        if (currentField === phnFields[2]) {
        }
    } 
}

function advanceDelivPhone() {
   var phnFields = document.getElementsByClassName("delivPhone");
   var currentField = document.activeElement;
   if (currentField.value.length === currentField.maxLength) {
       if (currentField === phnFields[0]) {
        phnFields[1].focus();
       }
       if (currentField === phnFields[1]) {
        phnFields[2].focus();
       }
       if (currentField === phnFields[2]) {
       }
   } 
}